/*3.Solicite ao usu�rio que insira 5 n�meros e calcule sua
m�dia usando um la�o do-while.*/

#include <stdio.h>

int main(){
    int num = 0, i = 1;
    do{
        printf("Numero %d: ",i);
        scanf("%d",&num);
        i++;
    }while(i<=5);
return 0;   
}
