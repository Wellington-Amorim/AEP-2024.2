/*1.Imprima os n�meros pares de 2 a 20 usando um la�o for*/
#include <stdio.h>

int main(){
    for(int i=2;i<=20;i++){
        printf(" %d",i);
        i += 1;             //soma o pr�prio n�mero + 1
    }   
return 0;     
}