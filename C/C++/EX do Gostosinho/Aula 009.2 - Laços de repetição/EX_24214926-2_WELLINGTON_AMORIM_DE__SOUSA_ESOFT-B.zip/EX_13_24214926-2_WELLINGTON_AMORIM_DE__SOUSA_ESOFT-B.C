/*13)CrieumalgoritmochamadoZod�aco.Estealgoritmodeve
solicitarparcialmenteadatadenascimento(diaem�s)e
apresentaroseusigno, conformetabelaabaixo:
Osignodozod�aco:Aqu�rio(21/jana19/fev)
Osignodozod�aco:Peixes (20/feva20/mar)
Osignodozod�aco:�ries (21/mara20/abr)
Osignodozod�aco:Touro(21/abra20/mai)
Osignodozod�aco:G�meos (21/maia20/jun)
Osignodozod�aco:C�ncer (21/juna21/jul)
Osignodozod�aco: Le�o(22/jula22/ago)
Osignodozod�aco:Virgem(23/agoa22/set)
Osignodozod�aco: Libra(23/seta22/out)
Osignodozod�aco:Escorpi�o(23/outa21/nov)
Osignodozod�aco:Sagit�rio(22/nova21/dez)
Osignodozod�aco:Capric�rnio(22/deza20/jan)
Nofinal,pergunteaousu�rioseeledesejacontinuar (SouN).*/
#include <stdio.h>

int main(){

return 0;    
}