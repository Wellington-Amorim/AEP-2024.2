/*11)Soliciteaidadede5pessoas.Nofinal,apresenteapessoa
mais velhaetamb�mapessoamais jovem.*/
#include <stdio.h>

int main(){

return 0;    
}