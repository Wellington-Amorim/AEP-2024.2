/*9)Soliciteaousu�rioonome,idadeesexo(F/M)dealgumas
pessoas.Acadaentrevista,osistemadever�perguntar
seousu�riodesejacontinuarainformardados,ecason�oqueira,
apresenteam�diadeidadedasmulheres.*/
#include <stdio.h>

int main(){
    int idade, quant;
    char nome[20], sexo, continuar;
    
    printf("Quantas pessoas voce quer fazer a intrevista?\n");
    scanf("%d",&quant);


        for(int i=1;i<=quant;i++){ 

        printf("NOME: \n");
        scanf("%s",nome);

        printf("IDADE: \n");
        scanf("%d",&idade);

        fflush(stdin);

        printf("SEXO(F/M): \n");
        sexo = getchar();

        fflush(stdin);
        
        printf("DESEJA CONTINUAR?(S/N)\n");
        continuar = getchar();

        if(continuar == "n" || continuar == "N"){
            i = quant;
        }
    
return 0;    
}
}
