/*10)Construaumalgoritmoquesoliciteosdadosdosalunos
(nome,nota1enota2)emumasaladeaulacontendo32
alunos.Posteriormente,apresenteam�diadaturmaeo
percentualdeaprovadosereprovados,considerandoquea
m�diam�nimaparaaprova��o�6,0.Obs.Asnotasfornecidas
dever�oservalidadasentre0e10.*/
#include <stdio.h>

int main(){

return 0;    
}