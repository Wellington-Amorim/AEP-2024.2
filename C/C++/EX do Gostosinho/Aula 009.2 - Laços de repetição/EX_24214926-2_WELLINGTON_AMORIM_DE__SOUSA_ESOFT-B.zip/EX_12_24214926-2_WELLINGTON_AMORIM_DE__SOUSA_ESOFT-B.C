/*12)Soliciteosdadosde12pessoas (idade, sexo,quantidadede
filhos)eposteriormenteapresente:
Opercentualdehomens
Am�diadeidadedasmulheres (semfilhos)
Aidadedapessoamais jovem
Aquantidadedemulheresentrevistadas
Obs.Todososdadosdever�oser validadosnaentrada.*/
#include <stdio.h>

int main(){

return 0;    
}